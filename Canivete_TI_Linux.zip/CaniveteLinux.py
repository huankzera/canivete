import customtkinter as ctk
from tkinter import Text, END, Scrollbar, messagebox
import subprocess
import threading
import os
import getpass
from datetime import datetime
import platform
import sys

class CaniveteLinux(ctk.CTk):
    def __init__(self):
        super().__init__()
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("dark-blue")
        
        self.title("CANIVETE TI LINUX PRO v1.0")
        self.geometry("1300x850")
        self.minsize(1150, 750)
        
        self.usuario = getpass.getuser()
        # Garante que o log fique na pasta do usuário não importa o SO
        self.log_path = os.path.expanduser("~/canivete_ti_linux_log.txt")
        
        self.verificar_ambiente()
        self.configurar_interface()
        
    def verificar_ambiente(self):
        # Tratamento especial para você conseguir testar a UI no Windows sem fechar o programa
        try:
            if os.geteuid() != 0:
                messagebox.showwarning(
                    "Aviso de Privilégios",
                    "Muitas funções de rede e disco precisam de root.\nRecomendado rodar o script com 'sudo python3 script.py'."
                )
        except AttributeError:
            # Se der erro de atributo, significa que está rodando no Windows
            messagebox.showinfo(
                "Modo de Teste (Windows)",
                "O sistema detectou que você está no Windows.\nA interface gráfica abrirá normalmente para você testar o layout, mas os comandos nativos do Linux retornarão erro ao clicar."
            )
    
    def configurar_interface(self):
        self.grid_columnconfigure(0, weight=0)
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)
        
        # ==================== SIDEBAR ====================
        sidebar = ctk.CTkFrame(self, width=280, corner_radius=0)
        sidebar.grid(row=0, column=0, sticky="nsew")
        sidebar.grid_propagate(False)
        
        ctk.CTkLabel(sidebar, text="CANIVETE TI LINUX", font=ctk.CTkFont(size=22, weight="bold")).pack(pady=(30, 5))
        ctk.CTkLabel(sidebar, text="v1.0 - Nível Técnico", text_color="gray", font=ctk.CTkFont(size=12)).pack(pady=(0, 30))
        
        # Botões Rápidos
        ctk.CTkButton(sidebar, text="⚡ AUTO FIX REDE", fg_color="#b8860b", hover_color="#8a6508", font=ctk.CTkFont(weight="bold"),
                      command=self.auto_fix_rede).pack(pady=10, padx=20, fill="x")
        
        ctk.CTkButton(sidebar, text="🔎 Diagnóstico Completo (TXT)", fg_color="#1f538d", hover_color="#14375e",
                      command=self.diagnostico_completo).pack(pady=10, padx=20, fill="x")
        
        ctk.CTkButton(sidebar, text="📋 Relatório de Hardware", fg_color="#1f538d", hover_color="#14375e",
                      command=self.relatorio_hardware).pack(pady=10, padx=20, fill="x")
        
        ctk.CTkButton(sidebar, text="🧹 Limpar Terminal", fg_color="#c42b1c", hover_color="#8a1f14",
                      command=self.limpar_tela).pack(pady=10, padx=20, fill="x")
        
        # Comando manual
        ctk.CTkLabel(sidebar, text="Comando Manual Bash:", font=ctk.CTkFont(size=12, weight="bold")).pack(pady=(20, 5), padx=20, anchor="w")
        self.entry_comando = ctk.CTkEntry(sidebar, placeholder_text="Ex: sudo ufw status")
        self.entry_comando.pack(pady=5, padx=20, fill="x")
        ctk.CTkButton(sidebar, text="Executar", fg_color="green", hover_color="darkgreen",
                      command=self.comando_manual).pack(pady=5, padx=20, fill="x")
        
        # Assinatura
        frame_ass = ctk.CTkFrame(sidebar, fg_color="transparent")
        frame_ass.pack(side="bottom", fill="x", pady=20)
        ctk.CTkLabel(frame_ass, text="Desenvolvido por", text_color="gray", font=ctk.CTkFont(size=11)).pack()
        ctk.CTkLabel(frame_ass, text="Matheus Huank!", text_color="#00ff00", font=ctk.CTkFont(size=14, weight="bold")).pack()
        
        # ==================== ÁREA PRINCIPAL ====================
        main_frame = ctk.CTkFrame(self)
        main_frame.grid(row=0, column=1, sticky="nsew", padx=10, pady=10)
        main_frame.grid_columnconfigure(0, weight=1)
        main_frame.grid_rowconfigure(0, weight=3) # Abas
        main_frame.grid_rowconfigure(1, weight=4) # Terminal
        
        tabview = ctk.CTkTabview(main_frame)
        tabview.grid(row=0, column=0, sticky="nsew", padx=10, pady=(0, 10))
        
        tab_rede        = tabview.add("🌐 Rede")
        tab_reparacao   = tabview.add("🧰 Sistema e Serviços")
        tab_limpeza     = tabview.add("🧹 Limpeza de Disco")
        tab_ferramentas = tabview.add("⚙ Ferramentas UI")
        
        self.construir_aba_comandos(tab_rede,        self.obter_comandos_rede(),        tipo="cmd")
        self.construir_aba_comandos(tab_reparacao,   self.obter_comandos_reparacao(),   tipo="cmd")
        self.construir_aba_comandos(tab_limpeza,     self.obter_comandos_limpeza(),     tipo="cmd")
        self.construir_aba_comandos(tab_ferramentas, self.obter_comandos_ferramentas(), tipo="janela")
        
        # Terminal
        output_frame = ctk.CTkFrame(main_frame)
        output_frame.grid(row=1, column=0, sticky="nsew", padx=10, pady=(0, 10))
        output_frame.grid_columnconfigure(0, weight=1)
        output_frame.grid_rowconfigure(0, weight=1)
        
        self.txt_output = Text(
            output_frame, bg="#0a0a0a", fg="#00ff00", font=("Consolas", 11),
            insertbackground="white", selectbackground="#003300", wrap="word", relief="flat"
        )
        scrollbar = Scrollbar(output_frame, command=self.txt_output.yview)
        self.txt_output.configure(yscrollcommand=scrollbar.set)
        self.txt_output.grid(row=0, column=0, sticky="nsew", padx=(5, 0), pady=5)
        scrollbar.grid(row=0, column=1, sticky="ns", pady=5)
        
        self.status = ctk.CTkLabel(self, text="Pronto - Aguardando comando...", anchor="w")
        self.status.grid(row=1, column=0, columnspan=2, sticky="ew", padx=10, pady=5)
        
        self.append_output("=== Canivete TI Linux v1.0 Iniciado ===\n", cor="cyan")
        self.append_output(f"Usuário Logado: {self.usuario}   |   Sistema Operacional: {platform.system()} {platform.release()}\n\n", cor="gray")
    
    # ====================== DICIONÁRIO DE COMANDOS (Foco Debian/Ubuntu/Mint) ======================
    def obter_comandos_rede(self):
        return [
            ("IPs Locais e Interfaces", "ip -c addr show", "Mostra os endereços IPv4, IPv6 e status das placas."),
            ("IP Público Externo", "curl ifconfig.me", "Consulta o seu endereço IP real na internet."),
            ("Renovar IP (DHCP)", "sudo dhclient -r && sudo dhclient", "Força a liberação e renovação do IP local."),
            ("Status do Firewall (UFW)", "sudo ufw status verbose", "Verifica se o firewall padrão do Ubuntu está bloqueando algo."),
            ("Limpar Cache DNS", "sudo resolvectl flush-caches", "Limpa o DNS local (resolve problemas de site fora do ar)."),
            ("Ping Google", "ping -c 4 8.8.8.8", "Testa a saída para a internet (4 pacotes)."),
            ("Traceroute (Rotas)", "traceroute -n 8.8.8.8", "Mostra os saltos sem tentar traduzir nomes (mais rápido)."),
            ("Testar DNS", "dig google.com +short", "Faz uma consulta limpa para ver se o DNS está traduzindo."),
            ("Portas Abertas (SS)", "sudo ss -tulnp", "Nova versão do netstat. Lista portas e programas (PID)."),
            ("Tabela ARP", "ip neigh show", "Lista os IPs e os endereços MAC conhecidos na sua rede."),
            ("Tabela de Roteamento", "ip route show", "Mostra as rotas e o gateway padrão do sistema."),
            ("Estatísticas da Placa", "ip -s link", "Mostra pacotes recebidos/enviados e perdas."),
            ("Reiniciar NetworkManager", "sudo systemctl restart NetworkManager", "Derruba e sobe toda a rede de uma vez.")
        ]
    
    def obter_comandos_reparacao(self):
        return [
            ("Erros Críticos de Boot", "journalctl -b -p err..alert", "Filtra apenas erros graves do Kernel desde a inicialização."),
            ("Serviços com Falha", "systemctl --failed", "Lista qualquer serviço (daemon) que tentou subir e quebrou."),
            ("Uso de RAM (Free)", "free -h", "Mostra o consumo de memória RAM e Swap de forma legível."),
            ("Espaço em Disco (DF)", "df -h", "Exibe a lotação de todas as partições do sistema."),
            ("Listar Hardware (LSHW)", "sudo lshw -short", "Resumo rápido de placa mãe, CPU, discos e rede."),
            ("Dispositivos USB", "lsusb", "Verifica teclados, mouses e placas de rede wireless conectadas."),
            ("Top 15 Processos Pesados", "top -b -n 1 | head -n 22", "Printa no terminal os processos que mais consomem CPU/RAM."),
            ("Tempo Ligado e Usuários", "uptime && w", "Mostra há quanto tempo o PC está ligado e quem está logado via SSH/TTY."),
            ("Versão do Kernel / SO", "uname -r && cat /etc/os-release | grep PRETTY_NAME", "Exibe a versão exata do sistema Linux."),
            ("Checar Disco no Boot", "sudo touch /forcefsck", "Obriga o sistema a rodar um chkdsk na próxima vez que ligar."),
            ("Reiniciar Sistema", "sudo reboot", "Reinicia a máquina imediatamente.")
        ]
    
    def obter_comandos_limpeza(self):
        return [
            ("Limpar Cache APT (Pacotes)", "sudo apt clean && sudo apt autoclean", "Remove pacotes .deb inúteis baixados em atualizações."),
            ("Remover Pacotes Órfãos", "sudo apt autoremove --purge -y", "Desinstala dependências de programas que já foram apagados."),
            ("Limpar Logs Antigos", "sudo journalctl --vacuum-time=7d", "Apaga logs de sistema com mais de 7 dias para liberar espaço."),
            ("Esvaziar Lixeira", "rm -rf ~/.local/share/Trash/*", "Força o esvaziamento da lixeira do seu usuário."),
            ("Limpar Cache de Imagens", "rm -rf ~/.cache/thumbnails/*", "Apaga o peso morto gerado por miniaturas de fotos e vídeos."),
            ("Limpar Histórico do Bash", "cat /dev/null > ~/.bash_history && history -c", "Limpa todos os comandos já digitados no terminal.")
        ]
    
    def obter_comandos_ferramentas(self):
        return [
            ("Monitor do Sistema UI", "gnome-system-monitor", "Abre o Gerenciador de Tarefas visual do GNOME."),
            ("Analisador de Disco UI", "baobab", "Abre o mapa visual de espaço em disco."),
            ("Terminal Root Independente", "x-terminal-emulator -e sudo bash", "Abre uma janela preta extra já com poderes de Root."),
            ("Atualizador de Softwares", "update-manager", "Abre a tela visual de atualizações do Ubuntu/Mint."),
            ("Configurações de Rede (NMTUI)", "x-terminal-emulator -e nmtui", "Interface de terminal para editar Wi-Fi e IP Fixo."),
            ("Explorador de Arquivos Root", "sudo nautilus || sudo nemo || sudo thunar", "Tenta abrir as pastas do sistema com permissão de edição."),
            ("Editor de Partições (GParted)", "sudo gparted", "Gerenciador visual de discos (requer estar instalado).")
        ]
    
    def construir_aba_comandos(self, aba, lista_comandos, tipo):
        scroll_frame = ctk.CTkScrollableFrame(aba, fg_color="transparent")
        scroll_frame.pack(fill="both", expand=True, padx=5, pady=5)
        
        scroll_frame.grid_columnconfigure(0, weight=0)
        scroll_frame.grid_columnconfigure(1, weight=1)
        
        for i, (texto_botao, comando, descricao) in enumerate(lista_comandos):
            if tipo == "cmd":
                btn = ctk.CTkButton(scroll_frame, text=texto_botao, width=220, anchor="w", fg_color="#2b2b2b", hover_color="#404040",
                                    command=lambda c=comando: self.executar_comando(c))
            else:
                btn = ctk.CTkButton(scroll_frame, text=texto_botao, width=220, anchor="w", fg_color="#5c4d0b", hover_color="#857116",
                                    command=lambda c=comando: self.abrir_ferramenta(c))
            
            btn.grid(row=i, column=0, padx=5, pady=4, sticky="w")
            lbl = ctk.CTkLabel(scroll_frame, text=descricao, text_color="#a3a3a3", font=ctk.CTkFont(size=12))
            lbl.grid(row=i, column=1, padx=10, pady=4, sticky="w")
    
    # ====================== FUNÇÕES ESPECIAIS ======================
    def auto_fix_rede(self):
        self.append_output("\n⚡ INICIANDO AUTO FIX DE REDE (LINUX)...\n", "yellow")
        comandos = [
            "sudo dhclient -r && sudo dhclient",
            "sudo resolvectl flush-caches",
            "sudo systemctl restart NetworkManager"
        ]
        for cmd in comandos:
            self.executar_comando(cmd)
    
    def diagnostico_completo(self):
        self.append_output("\n🔎 GERANDO DIAGNÓSTICO DE REDE E SISTEMA...\n", "yellow")
        self.atualizar_status("Escrevendo relatório TXT...")
        
        tempo = datetime.now().strftime("%d-%m-%Y_%H-%M-%S")
        arquivo = os.path.expanduser(f"~/diagnostico_linux_{tempo}.txt")
        
        # Lista limpa de comandos de infraestrutura
        comandos_diag = [
            "echo '=== DIAGNOSTICO COMPLETO LINUX ==='",
            "date",
            "echo '\n[ INFO DO SISTEMA ]'",
            "hostnamectl",
            "uname -a",
            "echo '\n[ INTERFACES E IPs ]'",
            "ip -c addr show",
            "echo '\n[ TABELA DE ROTAS ]'",
            "ip route show",
            "echo '\n[ PING GOOGLE ]'",
            "ping -c 4 8.8.8.8",
            "echo '\n[ RESOLUCAO DNS ]'",
            "cat /etc/resolv.conf",
            "echo '\n[ PORTAS ABERTAS ]'",
            "ss -tulnp",
            "echo '\n[ USO DE DISCO E RAM ]'",
            "df -h",
            "free -h"
        ]
        
        def rodar():
            with open(arquivo, "w", encoding="utf-8") as f:
                for cmd in comandos_diag:
                    if cmd.startswith("echo"):
                        # Remove o 'echo' e as aspas simples para escrever o título bonito no txt
                        titulo = cmd.replace("echo '", "").replace("'", "").replace("\\n", "\n")
                        f.write(f"{titulo}\n")
                    else:
                        try:
                            saida = subprocess.check_output(cmd, shell=True, text=True, stderr=subprocess.STDOUT)
                            f.write(saida + "\n")
                        except subprocess.CalledProcessError as e:
                            f.write(f"ERRO ao rodar comando: {e.output}\n")
            
            self.append_output(f"✅ Diagnóstico salvo com sucesso em:\n{arquivo}\n", "lime")
            self.atualizar_status("Pronto")
            
            # Tenta abrir o arquivo automaticamente com o editor padrão do Linux ou Windows
            try:
                if platform.system() == "Windows":
                    os.startfile(arquivo)
                else:
                    subprocess.Popen(["xdg-open", arquivo])
            except:
                pass

        threading.Thread(target=rodar, daemon=True).start()
    
    def relatorio_hardware(self):
        self.append_output("\n🔄 Coletando informações do Hardware...\n", "yellow")
        try:
            # Comandos em shell puro para buscar dados do Linux
            cpu = subprocess.getoutput("lscpu | grep 'Model name' | cut -d':' -f2 | xargs")
            ram = subprocess.getoutput("free -h | grep Mem | awk '{print $2}'")
            disco = subprocess.getoutput("df -h / | tail -1 | awk '{print $2}'")
            
            if platform.system() == "Windows":
                cpu = "Processador Oculto (Modo Windows)"
                ram = "N/A"
                disco = "N/A"
            
            texto = f"""
======================================
     RELATÓRIO DE HARDWARE - {datetime.now():%d/%m/%Y %H:%M}
======================================
Usuário     : {self.usuario}
Máquina     : {platform.node()}
Sistema     : {platform.system()} {platform.release()}
Processador : {cpu}
RAM Total   : {ram}
Disco Raiz  : {disco}
======================================
"""
            self.append_output(texto, "white")
            
            arq = os.path.expanduser(f"~/relatorio_hardware_{datetime.now():%d-%m-%Y_%H-%M-%S}.txt")
            with open(arq, "w", encoding="utf-8") as f:
                f.write(texto)
            self.append_output(f"✅ Salvo em: {arq}\n", "lime")
        except Exception as e:
            self.append_output(f"Erro: {e}\n", "red")
    
    # ====================== BASE DO TERMINAL ======================
    def append_output(self, texto: str, cor: str = "lime"):
        def atualizar():
            self.txt_output.tag_config(cor, foreground=cor)
            self.txt_output.insert(END, texto, cor)
            self.txt_output.see(END)
        self.after(0, atualizar)
    
    def atualizar_status(self, texto: str):
        self.after(0, lambda: self.status.configure(text=texto))
    
    def executar_comando(self, comando: str):
        threading.Thread(target=self._rodar_cmd, args=(comando,), daemon=True).start()
    
    def _rodar_cmd(self, comando: str):
        self.append_output(f"\nroot@linux:~# {comando}\n", "cyan")
        self.atualizar_status(f"Executando: {comando}...")
        
        try:
            process = subprocess.Popen(
                comando, shell=True,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, encoding="utf-8", errors="replace"
            )
            for linha in process.stdout:
                if linha.strip():
                    self.append_output(linha)
            process.wait()
            self.atualizar_status("Pronto")
        except Exception as e:
            self.append_output(f"FALHA: {str(e)}\n", "red")
            self.atualizar_status("Erro")
    
    def abrir_ferramenta(self, ferramenta: str):
        self.append_output(f"\n> Iniciando UI: {ferramenta}...\n", "yellow")
        try:
            subprocess.Popen(ferramenta, shell=True, start_new_session=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception as e:
            self.append_output(f"Erro ao abrir janela: {e}\n", "red")
    
    def comando_manual(self):
        cmd = self.entry_comando.get().strip()
        if not cmd:
            return
        
        # Proteção contra comandos que destroem o Linux (ex: rm -rf /)
        if "rm -rf /" in cmd.lower() or "mkfs" in cmd.lower():
            messagebox.showerror("Bloqueado", "O sistema de proteção bloqueou este comando altamente destrutivo.")
            return
            
        self.executar_comando(cmd)
        self.entry_comando.delete(0, END)
    
    def limpar_tela(self):
        self.txt_output.delete("1.0", END)
        self.append_output("=== Terminal Limpo ===\n", "cyan")

if __name__ == "__main__":
    app = CaniveteLinux()
    app.mainloop()